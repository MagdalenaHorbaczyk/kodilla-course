package com.kodilla.atm;

public class ATMImpl {
    @Override
    public void withdrawal(){
        System.out.println ("Cash"+" " + "withdrawal");
    }

    @Override
    public void deposit(){
        System.out.println ("Cash"+" " + "deposit");
    }
}
