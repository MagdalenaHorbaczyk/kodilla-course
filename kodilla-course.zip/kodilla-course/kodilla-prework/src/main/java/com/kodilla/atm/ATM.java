package com.kodilla.atm;

public class ATM {
    void withdrawal();

    void deposit();

    default void connectToBank() {
        System.out.println ("Connecting");
    }

    static String endOfTransaction() {
        return"Thank you";
    }
}
