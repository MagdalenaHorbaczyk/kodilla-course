package com.kodilla.atm;

public class Application {
    public static void main (String[] args) {
        ATMImpl bancomat = new ATMImpl();
        bancomat.withdrawal();
        bancomat.deposit();
        bancomat.connectToBank();
        System.out.println(ATM.endOfTransaction());
    }
}
